DROP DATABASE IF EXISTS ApplicationDatabase;
CREATE DATABASE ApplicationDatabase;

USE ApplicationDatabase;

DROP TABLE IF EXISTS EMPLOYEE;
CREATE TABLE EMPLOYEE (
	eId int not null,
	eFName varchar(25) not null,
	eLName varchar(25) not null,
	ePhone varchar(12) not null,
	eBNo int not null,
	constraint pk_eId primary key (eId)
);

DROP TABLE IF EXISTS MEDIA;
CREATE TABLE MEDIA (
	mNo int not null,
	mType varchar(25) not null,
	mName varchar(50) not null,
	mVideoLength int,
	URL varchar(200) not null,
	constraint pk_mNo primary key (mNo)
);

DROP TABLE IF EXISTS BRANCH;
CREATE TABLE BRANCH(
	bId       int not null,
	bAddress  varchar(50) not null,
	bPhone    varchar(12) not null,
	bName     char(25) not null,
	bManagerId int not null,
	constraint pk_bId primary key (bId)
);

DROP TABLE IF EXISTS COMPLETED;
CREATE TABLE COMPLETED(
	mNumber int not NULL,
	finished int not NULL,
	eId int not null,
	constraint pk_completed primary key (mNumber, eId)
);

-- Branch values
Insert into branch values ('0', 'Admin', '0', 'Admin', '0');

-- employee VALUES
insert into employee values ('0', 'Admin', 'Admin', '0', '0');

-- media VALUES
-- insert into media values ('0000', 'Article', 'Introduction', NULL);

-- completed VALUES
-- insert into completed values ('0000', '0000', TRUE);