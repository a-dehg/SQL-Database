import mysql.connector
from flask import Flask
from flask import render_template 
from flask import request, redirect

employee_login = None

###Change you password 
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  database='ApplicationDatabase',
  password="6snowBalls"
)
#this is what fixed the whole fucking code LMFAO!!!!!!!!!!!! SO FUCKING FUNNY!!
cursor = mydb.cursor()

def CountSelect(sql):
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        return results
    except:
        print("Error: unable to fetch data")
        return results
def Select(sql):
    try:
       # Execute the SQL command
        cursor.execute(sql)
       
       # Fetch all the rows in a list of lists.
        results = cursor.fetchall()
      ## print(results)
        for row in results:
            eId = row[0]
            eFName = row[1]
            eLName = row[2]
            ePhone = row[3]
            eBNo = row[4]
            #bManagerId = row[5]
          ## Now print fetched result
          ##print ("fname=%s,lname=%s,sex=%s,income=%d" % \
          ##       (fname, lname, sex, income ))
        return results
    
    except:
        print ("Error: unable to fecth data")
        return results

    
def SelectFromBranch(sql):
    
       # Execute the SQL command
        cursor.execute(sql)
       
       # Fetch all the rows in a list of lists.
        results = cursor.fetchall()
      ## print(results)
        for row in results:
            bManagerId = row[5]
          ## Now print fetched result
          ##print ("fname=%s,lname=%s,sex=%s,income=%d" % \
          ##       (fname, lname, sex, income ))
        return results
    


      
def Insert(sql):
    try:
       # Execute the SQL command
       cursor.execute(sql)
       # Commit your changes in the database
       mydb.commit()
    except:
       #Rollback in case there is any error
       mydb.rollback()
       print ("SOMETHING BAD HAPPENED")
       
def update(sql):
    try:
       # Execute the SQL command
       cursor.execute(sql)
       # Commit your changes in the database
       mydb.commit()
    except:
       # Rollback in case there is any error
       mydb.rollback()
       #print ("somethingbad happened")
       
def Delete(sql):
    try:
       # Execute the SQL command
       cursor.execute(sql)
       # Commit your changes in the database
       mydb.commit()
    except:
       # Rollback in case there is any error
       mydb.rollback()
       print ("somethingbad happened")
       
#Web interface starts here

app = Flask(__name__)



@app.route("/", methods=["GET", "POST"])
def Home():
    #Home page check home.html for the html format
    if request.method == "POST":
        login1 = request.form["login1"]
        login2 = request.form["login2"]
        global employee_login
        employee_login = login2
        #verifies that a manager (based off phone eId) exists
        sql = "SELECT bManagerId FROM BRANCH WHERE bManagerId = '%d';" % \
              (int(login2))
        managerIds = Select(sql)

        #verifies that the eId exists with its phone number
        sql = "SELECT eId FROM EMPLOYEE WHERE eId = '%d' AND ePhone = '%s';" % \
              (int(login2), str(login1))
        empVerify = Select(sql)
 

        #if the info they put in is fucking wrong
        if empVerify == []:
            return render_template('home.html')
    
        #if the info they put in is good for manager
        elif empVerify != [] and managerIds != []:
            return render_template('Manager.html')

        else:
            return render_template('employee.html') 

        

        
        
    return render_template('home.html')  

@app.route("/Employee")
def Employee():
    #Employee page with what he can do 
    return render_template('employee.html') 

@app.route("/Employee_Employee")
def Employee_Employee():
    #Employee can only view other employees with some atributes only 
    sql = "SELECT eFName, eLName FROM EMPLOYEE;"
    users= Select(sql)
#    
    return render_template('Employee_Employee.html', users=users)

@app.route("/Employee_Media")
def Employee_Media():
    
    
    sql = "select mNo, finished, mName, mType, URL from media join completed on mNo = mNumber where eId = '%d';" % \
              (int(employee_login))
    
    print(employee_login)
    
    users= Select(sql)
    
    return render_template('Employee_Media.html', users=users)


@app.route("/Employee_Complete", methods=["GET", "POST"])
def Employee_Complete():
    if request.method == "POST":
        mediaId = request.form["mediaId"]
        
        
        sql = "UPDATE COMPLETED SET finished = 1 WHERE eId = '%d' AND mNumber = '%d';"% \
              (int(employee_login), int(mediaId))

        update(sql)
        
        sql2 = "SELECT URL from media join completed on mNo = mNumber where eId = '%d' AND mNumber = '%d';"% \
              (int(employee_login), int(mediaId))

        Select(sql2)
        
        listofsql2 = Select(sql2)
        
        
        linkToPage = ' '.join([str(elem) for elem in listofsql2])
        
        linkToPage = linkToPage.replace("(",'')
        linkToPage = linkToPage.replace(")",'')
        linkToPage = linkToPage.replace("'",'')
        linkToPage = linkToPage.replace(",",'')
        print(linkToPage)
        
        return redirect(linkToPage)
    
    else:
        return render_template("Employee_Complete.html")

@app.route("/Manager")
def Manager():
    #Manger page with what he can do 

    return render_template('Manager.html')

@app.route("/Manager_Employee")
def Manager_Employee():
    #Specail select statement for the manager 
    sql = "SELECT * FROM EMPLOYEE;"
    users= Select(sql)
#     
    return render_template('Manager_Employee.html', users=users)


@app.route("/Manager_Media")
def Manager_Media():
    sql = "select mNo, eId, finished, mName, mType, URL from media join completed on mNo = mNumber;"
    users= Select(sql)
    
    return render_template('Manager_Media.html', users=users)



@app.route("/AddEmployee", methods=["GET", "POST"])
def addEmployee():
    #Adding an employee
    if request.method == "POST":
        eId = request.form["eId"]
        eFName = request.form["eFName"]
        eLName = request.form["eLName"]
        ePhone = request.form["ePhone"]
        eBNo = request.form["eBNo"]
        sql = "INSERT INTO EMPLOYEE(eId, eFName,eLName, ePhone, eBNo) \
            VALUES ('%d', '%s', '%s', '%s', '%d')" % \
            (int(eId), str(eFName), str(eLName), str(ePhone), int(eBNo))
        #print (sql)
        Insert(sql)
        sql = "SELECT mNo from media;"
        mNos = Select(sql)
        for i in mNos:
           sql = "Insert into completed(mNumber, finished, eId) \
               VALUES ('%d', '%d', '%d')" % \
               (int(i[0]), int(0), int(eId))
           Insert(sql)
        return redirect(request.url)
    return render_template("AddEmployee.html")

@app.route("/DeleteEmployee", methods=["GET", "POST"])
def DeleteEmployee():
    #Deleting an employee
    if request.method == "POST":
        fname = request.form["fname"]
        eId = request.form["eId"]
        print (fname,eId)
        sql = "Delete from EMPLOYEE where efname= '%s' and eId='%d' " % \
            (str(fname), int(eId))
        
        Delete (sql)
        sql = "Delete from Completed where eId = '%d'" % (int(eId))
        Delete(sql)

        return redirect(request.url)
    return render_template("DeleteEmployee.html")

@app.route("/CreateMedia", methods=["GET", "POST"])
def CreateMedia():
    if request.method =="POST":
        mNo = request.form["mNo"]
        mType = request.form["mType"]
        mName = request.form["mName"]
        mVideoLength = request.form["mVideoLength"]
        URL = request.form["URL"]
        sql = "INSERT INTO MEDIA(mNo, mType, mName, mVideoLength, URL) \
            VALUES ('%d', '%s', '%s', '%d', '%s')" % \
            (int(mNo), str(mType), str(mName), int(mVideoLength), str(URL))
        Insert(sql)
        sql = "SELECT eId from Employee;"
        empIds = Select(sql)
        for i in empIds:
            print(i[0])
            sql = "Insert into completed(mNumber, finished, eId) \
               VALUES ('%d', '%d', '%d')" % \
               (int(mNo), int(0), int(i[0]))
            Insert(sql)
        
        return redirect(request.url)
    return render_template("CreateMedia.html")
#You can add Update as well 
 


